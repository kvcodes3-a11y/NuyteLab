import { lazy, Suspense, useEffect, useMemo, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import {
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Bookmark,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Copy,
  FilePlus2,
  FileText,
  Filter,
  GitBranch,
  Library,
  Menu,
  MessageCircle,
  MoreHorizontal,
  NotebookPen,
  Plus,
  Search,
  Send,
  SlidersHorizontal,
  Sparkles,
  Star,
  UsersRound,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { demoPapers, type DemoSource } from "../../../shared/research-demo";

const Streamdown = lazy(() => import("streamdown").then(module => ({ default: module.Streamdown })));

type UiPaper = {
  id: string;
  slug: string;
  title: string;
  abstract: string;
  summary: string;
  paperBody: string;
  author: string;
  team: string;
  category: string;
  tags: string[];
  rating: number;
  reviewCount: number;
  readTime: number;
  version: number;
  status: "published" | "in_review" | "draft";
  createdAt: string | Date;
  sourceCount: number;
  isDemo: boolean;
  sources?: DemoSource[];
};

type ChatLine = { role: "assistant" | "visitor"; text: string };
type SessionProfile = { name?: string | null; email?: string | null; role?: string };
const categories = ["All papers", "AI & Society", "Computer Science", "Education", "Climate & Place"];
const demoUiPapers: UiPaper[] = demoPapers.map(paper => ({
  ...paper,
  rating: paper.rating,
  sourceCount: paper.sources.length,
  isDemo: true,
}));
const formatDate = (date: string | Date) => new Intl.DateTimeFormat("en", { month: "short", day: "numeric" }).format(new Date(date));
const shortNumber = (value: number) => value >= 1000 ? `${(value / 1000).toFixed(1)}k` : String(value);
const statusLabel = (status: UiPaper["status"]) => status === "published" ? "Published" : status === "in_review" ? "In review" : "Draft";
async function extractPaperFile(file: File) {
  if (file.size > 20 * 1024 * 1024) throw new Error("Keep source files under 20 MB for this hackathon MVP.");
  if (/\.pdf$/i.test(file.name) || file.type === "application/pdf") {
    const [pdfjsLib, workerModule] = await Promise.all([
      import("pdfjs-dist"),
      import("pdfjs-dist/build/pdf.worker.min.mjs?url"),
    ]);
    pdfjsLib.GlobalWorkerOptions.workerSrc = workerModule.default;
    const document = await pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
    const pageCount = Math.min(document.numPages, 60);
    const pageTexts: string[] = [];
    for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      const text = content.items.map(item => "str" in item ? item.str : "").filter(Boolean).join(" ");
      pageTexts.push(`[Page ${pageNumber}]\n${text}`);
    }
    const extracted = pageTexts.join("\n\n").slice(0, 50000);
    if (document.numPages > pageCount) toast.info(`Read the first ${pageCount} pages of this PDF.`);
    if (pageTexts.join("\n\n").length > 50000) toast.info("Source text was capped at 50,000 characters for this hackathon MVP.");
    if (extracted.trim().length < 80) throw new Error("No readable text found. If this is a scanned PDF, run OCR and paste the extracted text.");
    return extracted;
  }
  if (!/\.(txt|md|markdown)$/i.test(file.name) && !file.type.startsWith("text/")) {
    throw new Error("Upload a PDF, .txt or .md file, or paste extracted text.");
  }
  const text = await file.text();
  if (text.length > 50000) toast.info("Source text was capped at 50,000 characters for this hackathon MVP.");
  return text.slice(0, 50000);
}
const markdownForNotion = (paper: UiPaper, sources: DemoSource[] = []) => {
  const references = sources.map((source, index) => `${index + 1}. **${source.title}** — ${source.contributor}${source.citationUrl ? ` · ${source.citationUrl}` : ""}`).join("\n");
  return `# ${paper.title}\n\n> ${paper.abstract}\n\n**By ${paper.author} · ${paper.team} · ${paper.category} · Version ${paper.version}**\n\n${paper.summary || paper.paperBody}\n\n## Source contributions\n${references || `Source bundle contains ${paper.sourceCount} attributed contribution(s). Open Nuytelab to inspect the source text.`}\n\n---\n\n*Prepared with Nuytelab. Review source material and citations before public distribution.*`;
};

function normalizePaper(value: any): UiPaper {
  return {
    id: value.id,
    slug: value.slug,
    title: value.title,
    abstract: value.abstract ?? "",
    summary: value.summary ?? "",
    paperBody: value.paperBody ?? "",
    author: value.author ?? "Nuytelab member",
    team: value.team ?? "Open research",
    category: value.category ?? "Research",
    tags: Array.isArray(value.tags) ? value.tags : [],
    rating: Number(value.averageRating ?? value.rating ?? 0),
    reviewCount: Number(value.reviewCount ?? 0),
    readTime: Number(value.readTime ?? Math.max(3, Math.round((value.summary?.length ?? 1800) / 950))),
    version: Number(value.version ?? 1),
    status: value.status ?? "draft",
    createdAt: value.createdAt ?? new Date().toISOString(),
    sourceCount: Number(value.sourceCount ?? value.sources?.length ?? 0),
    isDemo: Boolean(value.isDemo),
    sources: value.sources,
  };
}

function Stars({ value, interactive = false, onChange }: { value: number; interactive?: boolean; onChange?: (value: number) => void }) {
  return (
    <span className={`star-row${interactive ? " star-row-interactive" : ""}`} aria-label={`${value} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map(star => interactive ? (
        <button key={star} type="button" onClick={() => onChange?.(star)} aria-label={`Rate ${star} stars`} className="star-button">
          <Star size={16} fill={star <= value ? "currentColor" : "none"} />
        </button>
      ) : <Star key={star} size={13} fill={star <= Math.round(value) ? "currentColor" : "none"} />)}
    </span>
  );
}

function PaperCard({ paper, onOpen, compact = false }: { paper: UiPaper; onOpen: () => void; compact?: boolean }) {
  return (
    <motion.button className={`paper-card${compact ? " paper-card-compact" : ""}`} onClick={onOpen} whileHover={{ y: -2 }} transition={{ duration: 0.16 }}>
      <div className="paper-card-top">
        <span className="category-label"><span className="category-dot" />{paper.category}</span>
        <span className={`status-pill status-${paper.status}`}>{statusLabel(paper.status)}</span>
      </div>
      <h3>{paper.title}</h3>
      <p className="paper-card-abstract">{paper.abstract}</p>
      <div className="paper-tags">{paper.tags.slice(0, 3).map(tag => <span key={tag}>{tag}</span>)}{paper.isDemo && <span className="demo-tag">Sample</span>}</div>
      <div className="paper-card-footer">
        <div className="author-chip"><span className="avatar avatar-mini">{paper.author.slice(0, 1)}</span><span>{paper.author}</span></div>
        <div className="paper-meta"><span><Star size={13} fill="currentColor" /> {paper.rating ? paper.rating.toFixed(1) : "New"}</span><span><MessageCircle size={13} /> {shortNumber(paper.reviewCount)}</span></div>
      </div>
      {!compact && <div className="paper-card-bottom"><span><GitBranch size={13} /> v{paper.version}</span><span><BookOpen size={13} /> {paper.readTime} min read</span><span>{formatDate(paper.createdAt)}</span></div>}
    </motion.button>
  );
}

function WorkspaceShell({ children, activeNav, setActiveNav, search, setSearch, onNewPaper, user, isTeamMember, isAdmin, onLogin, onLogout }: {
  children: React.ReactNode;
  activeNav: "discover" | "lab";
  setActiveNav: (value: "discover" | "lab") => void;
  search: string;
  setSearch: (value: string) => void;
  onNewPaper: () => void;
  user: SessionProfile | null;
  isTeamMember: boolean;
  isAdmin: boolean;
  onLogin: () => void;
  onLogout: () => void;
}) {
  const [mobileMenu, setMobileMenu] = useState(false);
  return (
    <div className="app-shell">
      <aside className={`sidebar${mobileMenu ? " sidebar-open" : ""}`}>
        <div className="brand-lockup"><span className="brand-mark"><span>n</span><i /></span><div><strong>NUYTELAB</strong><small>research, in the open</small></div><button className="icon-button sidebar-close" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={18} /></button></div>
        <div className="sidebar-label">WORKSPACE</div>
        <div className="workspace-switch"><span className="workspace-avatar">N</span><span><strong>Nuytelab team</strong><small>{isTeamMember ? "Open collaboration" : "Public reading · sign in to contribute"}</small></span><ChevronDown size={15} /></div>
        <div className="sidebar-label sidebar-label-spaced">YOUR LIBRARY</div>
        <nav className="side-nav" aria-label="Main navigation">
          <button className={activeNav === "discover" ? "active" : ""} onClick={() => { setActiveNav("discover"); setMobileMenu(false); }}><Library size={17} /><span>Discover</span><kbd>⌘ K</kbd></button>
          <button className={activeNav === "lab" ? "active" : ""} onClick={() => { setActiveNav("lab"); setMobileMenu(false); }}><NotebookPen size={17} /><span>My lab</span>{!isTeamMember && <span className="nav-count">Sign in</span>}</button>
          <button onClick={onNewPaper}><FilePlus2 size={17} /><span>New paper</span><Plus className="nav-plus" size={15} /></button>
        </nav>
        <div className="sidebar-rule" />
        <div className="sidebar-label">COLLABORATION</div>
        <div className="team-link"><span className="team-dot team-dot-terracotta" />Nuytelab research lab<span className="team-counter">{isTeamMember ? "Open" : "Sign in"}</span></div>
        <div className="sidebar-bottom">
          <div className="collab-card"><div className="collab-icon"><UsersRound size={16} /></div><strong>{isTeamMember ? "Work in the open." : "Read, then join in."}</strong><p>{isTeamMember ? "Any signed-in Manus account can add sources, shape drafts, and publish to the commons." : "Published papers are open to everyone. Sign in with any Manus account to contribute."}</p></div>
          {user ? <div className="profile-row"><span className="avatar profile-avatar">{(user.name || "M").slice(0, 1)}</span><span><strong>{user.name || "Manus member"}</strong><small>{isAdmin ? "Workspace admin" : "Signed-in collaborator"}</small></span><button className="profile-logout" onClick={onLogout}>Sign out</button></div> : <button className="profile-row profile-login" onClick={onLogin}><span className="avatar profile-avatar">N</span><span><strong>Sign in with Manus</strong><small>Any Manus account can contribute</small></span><ArrowRight size={16} />
          </button>}
        </div>
      </aside>
      {mobileMenu && <button className="mobile-scrim" onClick={() => setMobileMenu(false)} aria-label="Close navigation" />}
      <main className="main-area">
        <header className="topbar">
          <button className="icon-button mobile-menu-button" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={20} /></button>
          <div className="crumb"><span>Nuytelab</span><ChevronRight size={14} /><strong>{activeNav === "discover" ? "Discover" : "My lab"}</strong></div>
          <label className="global-search"><Search size={17} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search papers, topics, teams..." /><kbd>⌘ /</kbd></label>
          <button className="topbar-new" onClick={onNewPaper}><Plus size={16} /><span>{user ? "New paper" : "Sign in to contribute"}</span></button>
          <button className="icon-button help-button" onClick={() => toast("Nuytelab helps teams turn source material into shared research.")} aria-label="Help"><CircleHelp size={18} /></button>
        </header>
        {children}
      </main>
    </div>
  );
}

function CreatePaperDialog({ onClose, onCreate, pending, memberName }: {
  onClose: () => void;
  onCreate: (input: { title: string; abstract: string; team: string; category: string; sourceTitle: string; sourceContent: string; citationUrl: string }) => Promise<void>;
  pending: boolean;
  memberName: string;
}) {
  const [title, setTitle] = useState("");
  const [abstract, setAbstract] = useState("");
  const [team, setTeam] = useState("Nuytelab research team");
  const [category, setCategory] = useState("AI & Society");
  const [sourceTitle, setSourceTitle] = useState("");
  const [sourceContent, setSourceContent] = useState("");
  const [citationUrl, setCitationUrl] = useState("");
  const [fileName, setFileName] = useState("");

  const readFile = async (file?: File) => {
    if (!file) return;
    try {
      setFileName(file.name);
      setSourceTitle(file.name.replace(/\.[^.]+$/, ""));
      setSourceContent(await extractPaperFile(file));
      if (/\.pdf$/i.test(file.name)) toast.success("PDF text extracted in your browser; the original file was not uploaded.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not read that source file.");
    }
  };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    void onCreate({ title, abstract, team, category, sourceTitle, sourceContent, citationUrl });
  };

  return (
    <div className="dialog-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <motion.div className="dialog-card create-dialog" role="dialog" aria-modal="true" aria-labelledby="create-title" initial={{ opacity: 0, y: 12, scale: .99 }} animate={{ opacity: 1, y: 0, scale: 1 }}>
        <div className="dialog-header"><div><span className="eyebrow">START A SHARED PAPER</span><h2 id="create-title">Bring the sources.</h2><p>One team's working question, built from everyone's reading.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        <form onSubmit={submit} className="form-stack">
          <label className="field-label">Working title<input required minLength={6} maxLength={255} value={title} onChange={event => setTitle(event.target.value)} placeholder="What question is your team exploring?" /></label>
          <label className="field-label">Research question or short abstract<textarea required minLength={12} maxLength={2500} rows={2} value={abstract} onChange={event => setAbstract(event.target.value)} placeholder="Give your contributors a little context..." /></label>
          <label className="field-label">Team name<input required minLength={2} value={team} onChange={event => setTeam(event.target.value)} /></label>
          <div className="privacy-note"><Check size={14} />Attributed to your verified Manus account: <strong>{memberName}</strong></div>
          <label className="field-label">Research area<select value={category} onChange={event => setCategory(event.target.value)}>{categories.slice(1).map(item => <option key={item}>{item}</option>)}<option>Other research</option></select></label>
          <div className="source-upload-head"><div><span className="eyebrow">FIRST SOURCE</span><p>Start with at least one contribution. Add teammates' sources after creating the paper.</p></div><label className="upload-chip"><FilePlus2 size={15} />{fileName ? "Replace file" : "Upload PDF / text"}<input type="file" accept=".pdf,.txt,.md,.markdown,application/pdf,text/plain,text/markdown" onChange={event => void readFile(event.target.files?.[0])} /></label></div>
          <label className="field-label">Source title<input required minLength={2} value={sourceTitle} onChange={event => setSourceTitle(event.target.value)} placeholder="Paper title, notes, or source bundle" /></label>
          <label className="field-label">Source text or notes<textarea required minLength={80} maxLength={50000} rows={5} value={sourceContent} onChange={event => setSourceContent(event.target.value)} placeholder="Paste the source text or your team's reading notes..." /><small className="field-hint">{sourceContent.length.toLocaleString()} characters · PDFs are text-extracted in your browser; scanned files need OCR</small></label>
          <label className="field-label">Source URL <span className="optional-label">optional</span><input value={citationUrl} onChange={event => setCitationUrl(event.target.value)} placeholder="https://doi.org/..." /></label>
          <div className="dialog-footer"><span className="privacy-note"><Sparkles size={14} />AI synthesis starts after saving. Review before sharing.</span><button className="button-primary" type="submit" disabled={pending || sourceContent.trim().length < 80}>{pending ? <><span className="button-spinner" />Building your paper...</> : <>Create paper <ArrowRight size={16} /></>}</button></div>
        </form>
      </motion.div>
    </div>
  );
}

function ContributionDialog({ paperTitle, memberName, onClose, onSubmit, pending }: {
  paperTitle: string;
  memberName: string;
  onClose: () => void;
  onSubmit: (input: { title: string; content: string; citationUrl: string }) => Promise<void>;
  pending: boolean;
}) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [citationUrl, setCitationUrl] = useState("");
  const [fileName, setFileName] = useState("");
  const submit = (event: FormEvent) => { event.preventDefault(); void onSubmit({ title, content, citationUrl }); };
  const readFile = async (file?: File) => {
    if (!file) return;
    try {
      setFileName(file.name); setTitle(file.name.replace(/\.[^.]+$/, "")); setContent(await extractPaperFile(file));
      if (/\.pdf$/i.test(file.name)) toast.success("PDF text extracted in your browser; the original file was not uploaded.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Could not read that source file."); }
  };
  return (
    <div className="dialog-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <motion.div className="dialog-card" role="dialog" aria-modal="true" aria-labelledby="contribution-title" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <div className="dialog-header"><div><span className="eyebrow">ADD TO THE SOURCE TRAIL</span><h2 id="contribution-title">Bring another perspective.</h2><p>Adding a source to <em>{paperTitle}</em>.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        <form onSubmit={submit} className="form-stack">
          <div className="source-upload-head"><p>Contributing as <strong>{memberName}</strong>. The verified account name is recorded with the source.</p><label className="upload-chip"><FilePlus2 size={15} />{fileName || "Upload PDF / text"}<input type="file" accept=".pdf,.txt,.md,.markdown,application/pdf,text/plain,text/markdown" onChange={event => void readFile(event.target.files?.[0])} /></label></div>
          <label className="field-label">Source title<input required minLength={2} value={title} onChange={event => setTitle(event.target.value)} placeholder="Title or reading notes" /></label>
          <label className="field-label">Source text<textarea required minLength={80} maxLength={50000} rows={7} value={content} onChange={event => setContent(event.target.value)} placeholder="Paste the research text, excerpts, or notes..." /></label>
          <label className="field-label">Source URL <span className="optional-label">optional</span><input value={citationUrl} onChange={event => setCitationUrl(event.target.value)} placeholder="https://doi.org/..." /></label>
          <div className="dialog-footer"><span className="privacy-note"><GitBranch size={14} />Your source joins the paper's history.</span><button className="button-primary" type="submit" disabled={pending || content.trim().length < 80}>{pending ? "Adding source…" : <>Add contribution <ArrowRight size={16} /></>}</button></div>
        </form>
      </motion.div>
    </div>
  );
}

function ReviewDialog({ paper, onClose, onSubmit, pending }: { paper: UiPaper; onClose: () => void; onSubmit: (reviewer: string, rating: number, text: string) => Promise<void>; pending: boolean }) {
  const [reviewer, setReviewer] = useState("");
  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");
  const submit = (event: FormEvent) => { event.preventDefault(); void onSubmit(reviewer, rating, text); };
  return (
    <div className="dialog-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <motion.div className="dialog-card review-dialog" role="dialog" aria-modal="true" aria-labelledby="review-title" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <div className="dialog-header"><div><span className="eyebrow">COMMUNITY REVIEW</span><h2 id="review-title">Read it with care.</h2><p>Your review helps the next reader evaluate this paper.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        <form onSubmit={submit} className="form-stack"><div className="rate-field"><span className="field-label">Your rating</span><Stars value={rating} interactive onChange={setRating} /><span className="rating-caption">{rating === 5 ? "Thoughtful and rigorous" : rating >= 4 ? "Strong contribution" : rating >= 3 ? "Worth discussing" : "Needs more work"}</span></div>
          <label className="field-label">Your name<input required minLength={2} value={reviewer} onChange={event => setReviewer(event.target.value)} placeholder="Name or reading group" /></label>
          <label className="field-label">Review<textarea required minLength={10} maxLength={4000} rows={4} value={text} onChange={event => setText(event.target.value)} placeholder="What holds up? What should the authors clarify?" /></label>
          <div className="dialog-footer"><span className="privacy-note">Keep it constructive and specific.</span><button className="button-primary" type="submit" disabled={pending || text.trim().length < 10}>{pending ? "Saving review…" : <>Publish review <ArrowRight size={16} /></>}</button></div>
        </form>
      </motion.div>
    </div>
  );
}

function ChatPanel({ paperId, paperTitle }: { paperId: string; paperTitle: string }) {
  const [question, setQuestion] = useState("");
  const [lines, setLines] = useState<ChatLine[]>([]);
  const ask = trpc.research.ask.useMutation();
  const sendQuestion = async (prompt = question) => {
    const text = prompt.trim();
    if (!text || ask.isPending) return;
    setQuestion("");
    setLines(previous => [...previous, { role: "visitor", text }]);
    try {
      const result = await ask.mutateAsync({ paperId, question: text });
      setLines(previous => [...previous, { role: "assistant", text: result.answer }]);
    } catch (error) {
      const message = error instanceof Error ? error.message : "The research assistant could not respond right now.";
      setLines(previous => [...previous, { role: "assistant", text: `I couldn't retrieve an answer just now. ${message}` }]);
    }
  };
  return (
    <section className="chat-card">
      <div className="chat-heading"><span className="chat-orb"><Sparkles size={16} /></span><div><strong>Ask this paper</strong><small>Answers cite the source bundle</small></div><span className="online-dot" /></div>
      <div className="chat-transcript" aria-live="polite">
        {lines.length === 0 ? <div className="chat-welcome"><span className="chat-scribble">“</span><p>Curious about a claim, source, or limitation? Ask {paperTitle.split(" ").slice(0, 3).join(" ")}.</p><div className="suggested-questions"><button onClick={() => void sendQuestion("What are the main limitations?")}>What are the main limitations?</button><button onClick={() => void sendQuestion("Which sources support the key finding?")}>Which sources support the key finding?</button></div></div> : lines.map((line, index) => <div className={`chat-line chat-${line.role}`} key={`${line.role}-${index}`}><span className="chat-line-avatar">{line.role === "assistant" ? <Sparkles size={13} /> : "M"}</span><div><small>{line.role === "assistant" ? "Paper guide" : "You"}</small><p>{line.text}</p></div></div>)}
        {ask.isPending && <div className="chat-line chat-assistant"><span className="chat-line-avatar"><Sparkles size={13} /></span><div><small>Paper guide</small><p className="thinking-dots"><i /><i /><i /></p></div></div>}
      </div>
      <form className="chat-input-row" onSubmit={event => { event.preventDefault(); void sendQuestion(); }}><input value={question} onChange={event => setQuestion(event.target.value)} placeholder="Ask a question..." aria-label="Ask about this paper" /><button type="submit" disabled={!question.trim() || ask.isPending} aria-label="Send question"><Send size={16} /></button></form>
      <div className="chat-disclaimer">AI answers can miss nuance. Check the cited sources.</div>
    </section>
  );
}

function DetailView({ paper, onBack, onAddSource, onReview, onSynthesize, onExport, onPublish, onPublishNotion, publishPending, notionPending, notionConnected, synthPending, detailData, canEdit, canReview, isAdmin }: {
  paper: UiPaper;
  onBack: () => void;
  onAddSource: () => void;
  onReview: () => void;
  onSynthesize: () => void;
  onExport: () => void;
  onPublish: () => void;
  onPublishNotion: () => void;
  publishPending: boolean;
  notionPending: boolean;
  notionConnected: boolean;
  synthPending: boolean;
  detailData?: any;
  canEdit: boolean;
  canReview: boolean;
  isAdmin: boolean;
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [draftSummary, setDraftSummary] = useState(paper.summary || paper.paperBody);
  const [changeNote, setChangeNote] = useState("Edited for clarity and source attribution");
  const saveRevision = trpc.research.saveRevision.useMutation();
  const utils = trpc.useUtils();
  useEffect(() => { setDraftSummary(paper.summary || paper.paperBody); }, [paper.id, paper.summary, paper.paperBody]);
  const sources: DemoSource[] = detailData?.sources?.map((source: any) => ({ contributor: source.contributor, title: source.title, content: source.content, citationUrl: source.citationUrl ?? undefined })) ?? paper.sources ?? [];
  const revisions = detailData?.revisions as Array<{ version: number; changeNote: string; createdBy: string; createdAt: string | Date }> | undefined;
  const reviews = detailData?.reviews as Array<{ reviewer: string; rating: number; review: string; createdAt: string | Date }> | undefined;
  const notionPublications = detailData?.notionPublications as Array<{ version: number; notionUrl: string; createdAt: string | Date }> | undefined;
  const articleText = paper.summary || paper.paperBody || paper.abstract;
  const citations = sources.map((source, index) => ({ ...source, number: index + 1 }));
  const handleSaveRevision = async () => {
    try {
      await saveRevision.mutateAsync({ paperId: paper.id, summary: draftSummary, changeNote });
      await Promise.all([utils.research.list.invalidate(), utils.research.workspace.invalidate(), utils.research.workspaceDetail.invalidate({ paperId: paper.id }), utils.research.detail.invalidate({ paperId: paper.id })]);
      setIsEditing(false);
      toast.success("Editorial revision saved in the paper history.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save this revision.");
    }
  };
  return (
    <motion.div className="detail-page" initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: .2 }}>
      <div className="detail-breadcrumb"><button onClick={onBack}><ArrowLeft size={15} /> Back to papers</button><span>/</span><span>{paper.team}</span><span>/</span><strong>{paper.slug}</strong></div>
      <div className="detail-hero">
        <div className="detail-title-side"><div className="paper-card-top"><span className="category-label"><span className="category-dot" />{paper.category}</span><span className={`status-pill status-${paper.status}`}>{statusLabel(paper.status)}</span>{paper.isDemo && <span className="demo-tag">Sample paper</span>}</div>
          <h1>{paper.title}</h1><p className="detail-abstract">{paper.abstract}</p>
          <div className="detail-byline"><span className="avatar">{paper.author.slice(0, 1)}</span><span><strong>{paper.author}</strong><small>{paper.team} · {formatDate(paper.createdAt)}</small></span><span className="byline-separator" /><span className="detail-stat"><Star size={15} fill="currentColor" /> {paper.rating ? paper.rating.toFixed(1) : "New"} <small>({paper.reviewCount})</small></span><span className="detail-stat"><BookOpen size={15} /> {paper.readTime} min read</span></div>
        </div>
        <div className="detail-actions">{canEdit && <><button className="button-quiet" onClick={onAddSource}><Plus size={15} /> Add source</button><button className="button-quiet" onClick={() => setIsEditing(true)} disabled={paper.isDemo || !paper.summary || isEditing}><NotebookPen size={14} /> Edit synthesis</button><button className="button-quiet" onClick={onSynthesize} disabled={synthPending || paper.isDemo}>{synthPending ? <><span className="button-spinner" />Synthesizing</> : <><Sparkles size={14} /> Synthesize</>}</button>{paper.status !== "published" && !paper.isDemo && <button className="button-primary" onClick={onPublish} disabled={!paper.summary || publishPending}>{publishPending ? "Publishing…" : <>Publish to commons <ArrowUpRight size={14} /></>}</button>}</>}<button className="button-quiet" onClick={onExport}><Copy size={15} /> Notion-ready export</button>{canReview && <button className="icon-button" onClick={onReview} aria-label="Write a review"><MoreHorizontal size={19} /></button>}</div>
      </div>
      {paper.isDemo && <div className="demo-notice"><span className="demo-notice-mark">i</span><span><strong>Sample content</strong> · This example is fictional demo material. Upload your own source bundle to generate evidence-grounded work.</span></div>}
      <div className="detail-layout">
        <div className="manuscript-column">
          <div className="manuscript-meta"><span><FileText size={14} /> PAPER</span><span className="version-label"><GitBranch size={14} /> version {paper.version}.0</span><button className="text-button" onClick={onExport}>Export <ArrowUpRight size={13} /></button></div>
          <div className="manuscript-content">
            <div className="manuscript-kicker"><span>NUYTELAB · OPEN RESEARCH</span><span>{paper.category.toUpperCase()}</span></div>
            <div className="annotation-rule" />
            <h2>{paper.title}</h2>
            <div className="paper-author-block"><span>{paper.author}</span><span>{paper.team}</span><span>Version {paper.version} · {formatDate(paper.createdAt)}</span></div>
            <section className="paper-section abstract-section"><div className="section-margin"><span>ABSTRACT</span><i /></div><p>{paper.abstract}</p></section>
            <section className="paper-section"><div className="section-margin"><span>{isEditing ? "EDIT REVISION" : "THE PAPER"}</span><i /></div>{isEditing ? <div className="revision-editor"><textarea value={draftSummary} onChange={event => setDraftSummary(event.target.value)} rows={18} aria-label="Edit paper synthesis" /><label>Revision note<input value={changeNote} onChange={event => setChangeNote(event.target.value)} maxLength={255} /></label><div className="revision-editor-actions"><button className="button-quiet" onClick={() => { setDraftSummary(articleText); setIsEditing(false); }}>Cancel</button><button className="button-primary" onClick={() => void handleSaveRevision()} disabled={saveRevision.isPending || draftSummary.trim().length < 80 || changeNote.trim().length < 3}>{saveRevision.isPending ? "Saving revision…" : <>Save revision <Check size={14} /></>}</button></div></div> : <div className="markdown-body"><Suspense fallback={<div className="markdown-loading">Preparing paper text…</div>}><Streamdown>{articleText}</Streamdown></Suspense></div>}</section>
            <section className="paper-section source-section"><div className="section-margin"><span>SOURCE TRAIL</span><i /></div>
              {citations.length ? <ol className="source-citations">{citations.map(source => <li key={`${source.title}-${source.number}`}><span className="citation-number">S{source.number}</span><div><strong>{source.title}</strong><small>Contributed by {source.contributor}</small>{source.citationUrl && <a href={source.citationUrl} target="_blank" rel="noreferrer">Open source <ArrowUpRight size={12} /></a>}</div></li>)}</ol> : <div className="source-empty"><FileText size={18} /><span>{paper.sourceCount} attributed source contribution(s). Add a source to make the paper trail visible.</span></div>}
              {canEdit && <button className="add-source-inline" onClick={onAddSource}><Plus size={14} /> Contribute another source</button>}
            </section>
          </div>
          <div className="review-section">
            <div className="review-section-head"><div><span className="eyebrow">COMMUNITY READING</span><h3>In the margins</h3></div>{canReview && <button className="button-quiet" onClick={onReview}><Plus size={14} /> Write a review</button>}</div>
            {reviews?.length ? <div className="review-list">{reviews.slice(0, 3).map((review, index) => <div className="review-item" key={`${review.reviewer}-${index}`}><div className="review-item-top"><strong>{review.reviewer}</strong><Stars value={review.rating} /><span>{formatDate(review.createdAt)}</span></div><p>{review.review}</p></div>)}</div> : <div className="review-empty"><span className="review-quote">“</span><p>Good reviews don't just rate a paper. They show the next reader where to look.</p>{canReview && <button onClick={onReview}>Be the first to leave a note <ArrowRight size={14} /></button>}</div>}
          </div>
        </div>
        <aside className="detail-aside">
          <ChatPanel paperId={paper.id} paperTitle={paper.title} />
          <section className="aside-card version-card"><div className="aside-card-heading"><span className="aside-icon"><GitBranch size={16} /></span><div><strong>Version history</strong><small>{revisions?.length ?? paper.version} saved revision{(revisions?.length ?? paper.version) === 1 ? "" : "s"}</small></div><button className="icon-button tiny-button" aria-label="Version history"><ArrowUpRight size={15} /></button></div>
            <div className="timeline">{(revisions?.length ? revisions.slice(0, 4) : Array.from({ length: Math.min(paper.version, 3) }, (_, index) => ({ version: paper.version - index, changeNote: index === 0 ? "Current published version" : "Research synthesis updated", createdBy: paper.author, createdAt: paper.createdAt }))).map((revision, index) => <div className={`timeline-item${index === 0 ? " timeline-current" : ""}`} key={`${revision.version}-${index}`}><span className="timeline-dot">{index === 0 && <i />}</span><div><strong>v{revision.version}.0 <small>{index === 0 ? "CURRENT" : ""}</small></strong><p>{revision.changeNote}</p><span>{revision.createdBy} · {formatDate(revision.createdAt)}</span></div></div>)}</div>
            {canEdit && <button className="aside-text-link" onClick={onAddSource}>Contribute to next version <ArrowRight size={14} /></button>}
          </section>
          <section className="aside-card contributors-card"><div className="aside-card-heading"><span className="aside-icon"><UsersRound size={16} /></span><div><strong>Contributors</strong><small>{new Set(sources.map(source => source.contributor)).size || 1} voices in this paper</small></div></div>
            {(sources.length ? sources : [{ contributor: paper.author, title: "Project lead", content: "" }]).slice(0, 4).map((source, index) => <div className="contributor-row" key={`${source.contributor}-${index}`}><span className={`avatar avatar-${index % 4}`}>{source.contributor.slice(0, 1)}</span><span><strong>{source.contributor}</strong><small>{source.title}</small></span><span className="contributor-source-count">{sources.filter(item => item.contributor === source.contributor).length || 1}</span></div>)}
            {canEdit && <button className="aside-text-link" onClick={onAddSource}>Add a perspective <Plus size={14} /></button>}
          </section>
          <section className="notion-card"><span className="notion-stamp">N</span><div><strong>{isAdmin ? notionConnected ? "Publish to Notion" : "Notion connection needed" : "Notion-ready export"}</strong><p>{isAdmin ? notionConnected ? "Add a row with the release date, full Summary text, and concise Review." : "Connect a Notion integration to publish directly, or prepare a page to paste." : "Direct Notion publishing is restricted to the workspace owner. Copy a clean Markdown edition instead."}</p>{isAdmin && notionConnected && paper.status === "published" && !paper.isDemo ? <button onClick={onPublishNotion} disabled={notionPending}>{notionPending ? "Publishing…" : `Publish v${paper.version}.0`} <ArrowRight size={13} /></button> : <button onClick={onExport}>Prepare page <ArrowRight size={13} /></button>}</div></section>
          {notionPublications?.length ? <section className="aside-card notion-history-card"><div className="aside-card-heading"><span className="aside-icon"><BookOpen size={16} /></span><div><strong>Notion editions</strong><small>{notionPublications.length} version{notionPublications.length === 1 ? "" : "s"} published</small></div></div>{notionPublications.slice(0, 4).map(publication => <a className="notion-edition-link" key={`${publication.version}-${publication.notionUrl}`} href={publication.notionUrl} target="_blank" rel="noreferrer"><span>v{publication.version}.0</span><span>Open page <ArrowUpRight size={12} /></span></a>)}</section> : null}
          {paper.isDemo && <div className="aside-disclaimer"><Bookmark size={14} /> Keep demo citations separate from real project evidence.</div>}
        </aside>
      </div>
    </motion.div>
  );
}

export default function Home() {
  const [activeNav, setActiveNav] = useState<"discover" | "lab">("discover");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All papers");
  const [sortBy, setSortBy] = useState<"momentum" | "recent">("momentum");
  const [selectedPaperId, setSelectedPaperId] = useState<string | null>(null);
  const [dialog, setDialog] = useState<"create" | "contribution" | "review" | "export" | null>(null);
  const [exportText, setExportText] = useState("");
  const auth = useAuth();
  const user = auth.user;
  const isAdmin = user?.role === "admin";
  const utils = trpc.useUtils();
  const queryClient = useQueryClient();
  const listQuery = trpc.research.list.useQuery(undefined, { retry: 1, refetchOnWindowFocus: false });
  const isTeamMember = Boolean(user);
  const workspaceQuery = trpc.research.workspace.useQuery(undefined, { enabled: isTeamMember, retry: false, refetchOnWindowFocus: false });
  const publicPapers = useMemo(() => listQuery.data?.length ? (listQuery.data as any[]).map(normalizePaper) : demoUiPapers, [listQuery.data]);
  const workspacePapers = useMemo(() => isTeamMember ? (workspaceQuery.data as any[] | undefined)?.map(normalizePaper) ?? [] : [], [isTeamMember, workspaceQuery.data]);
  const papers = useMemo(() => Array.from(new Map([...publicPapers, ...workspacePapers].map(paper => [paper.id, paper])).values()), [publicPapers, workspacePapers]);
  const selectedPaper = papers.find(paper => paper.id === selectedPaperId);
  const selectedIsTeamPaper = Boolean(isTeamMember && selectedPaper && !selectedPaper.isDemo);
  const detailQuery = trpc.research.detail.useQuery({ paperId: selectedPaperId ?? "" }, { enabled: Boolean(selectedPaperId && !selectedIsTeamPaper), retry: false });
  const workspaceDetailQuery = trpc.research.workspaceDetail.useQuery({ paperId: selectedPaperId ?? "" }, { enabled: Boolean(selectedPaperId && selectedIsTeamPaper), retry: false });
  const detailData = selectedIsTeamPaper ? workspaceDetailQuery.data : detailQuery.data;
  const notionStatus = trpc.research.notionStatus.useQuery(undefined, { enabled: Boolean(isAdmin), refetchOnWindowFocus: false, retry: false });
  const createPaper = trpc.research.createPaper.useMutation();
  const addContribution = trpc.research.addContribution.useMutation();
  const synthesize = trpc.research.synthesize.useMutation();
  const submitReview = trpc.research.review.useMutation();
  const publishPaper = trpc.research.publishToCommons.useMutation();
  const publishNotion = trpc.research.publishToNotion.useMutation();

  const detailPaper = selectedPaper && detailData ? normalizePaper(detailData) : selectedPaper;
  const resultPapers = useMemo(() => {
    let rows = activeNav === "lab" ? workspacePapers : publicPapers;
    if (category !== "All papers") rows = rows.filter(paper => paper.category === category);
    const query = search.trim().toLowerCase();
    if (query) rows = rows.filter(paper => [paper.title, paper.abstract, paper.author, paper.team, paper.category, ...paper.tags].join(" ").toLowerCase().includes(query));
    if (sortBy === "momentum") rows = [...rows].sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount);
    else rows = [...rows].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return rows;
  }, [workspacePapers, publicPapers, activeNav, category, search, sortBy]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault(); document.querySelector<HTMLInputElement>(".global-search input")?.focus();
      }
      if (event.key === "Escape") { setDialog(null); setSelectedPaperId(null); }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const handleLogin = () => {
    try { startLogin(); } catch (error) { toast.error(error instanceof Error ? error.message : "Manus sign-in is not configured."); }
  };
  const handleLogout = async () => {
    try {
      await auth.logout();
      toast.success("Signed out. Private workspace data was cleared from this session.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not sign out cleanly.");
    } finally {
      queryClient.clear();
      setDialog(null);
      setSelectedPaperId(null);
      setActiveNav("discover");
    }
  };
  const handleNewPaper = () => {
    if (!user) { handleLogin(); return; }
    setDialog("create");
  };
  const refreshPapers = async () => { await Promise.all([utils.research.list.invalidate(), utils.research.workspace.invalidate()]); };
  const handleCreate = async (input: { title: string; abstract: string; team: string; category: string; sourceTitle: string; sourceContent: string; citationUrl: string }) => {
    try {
      const created = await createPaper.mutateAsync(input);
      await refreshPapers();
      setDialog(null);
      setSelectedPaperId(created.paperId);
      setActiveNav("lab");
      toast.success("Paper workspace created. The source trail is in place.");
      try {
        await synthesize.mutateAsync({ paperId: created.paperId });
        await refreshPapers();
        await utils.research.workspaceDetail.invalidate({ paperId: created.paperId });
        toast.success("First synthesis is ready for your review.");
      } catch (error) {
        toast.error(error instanceof Error ? `Source saved. AI synthesis couldn't run: ${error.message}` : "Source saved. AI synthesis couldn't run yet.");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not create that paper.");
    }
  };
  const handleContribution = async (input: { title: string; content: string; citationUrl: string }) => {
    if (!selectedPaperId) return;
    try {
      await addContribution.mutateAsync({ ...input, paperId: selectedPaperId });
      await Promise.all([refreshPapers(), utils.research.workspaceDetail.invalidate({ paperId: selectedPaperId }), utils.research.detail.invalidate({ paperId: selectedPaperId })]);
      setDialog(null);
      toast.success("Contribution added to the source trail.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not add that source.");
    }
  };
  const handleSynthesis = async () => {
    if (!selectedPaperId || !detailPaper) return;
    try {
      await synthesize.mutateAsync({ paperId: selectedPaperId });
      await Promise.all([refreshPapers(), utils.research.workspaceDetail.invalidate({ paperId: selectedPaperId }), utils.research.detail.invalidate({ paperId: selectedPaperId })]);
      toast.success("New synthesis saved as a version for review.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Synthesis could not be generated.");
    }
  };
  const handlePublish = async () => {
    if (!selectedPaperId) return;
    try {
      await publishPaper.mutateAsync({ paperId: selectedPaperId });
      await Promise.all([refreshPapers(), utils.research.workspaceDetail.invalidate({ paperId: selectedPaperId }), utils.research.detail.invalidate({ paperId: selectedPaperId })]);
      toast.success("Paper published to the Nuytelab commons.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not publish this paper.");
    }
  };
  const handlePublishToNotion = async () => {
    if (!selectedPaperId) return;
    try {
      const result = await publishNotion.mutateAsync({ paperId: selectedPaperId });
      await utils.research.workspaceDetail.invalidate({ paperId: selectedPaperId });
      toast.success(result.alreadyPublished ? `Version ${result.version}.0 already has a Notion page.` : `Version ${result.version}.0 published to Notion.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not publish to Notion.");
    }
  };
  const handleReview = async (reviewer: string, rating: number, text: string) => {
    if (!selectedPaperId) return;
    try {
      await submitReview.mutateAsync({ paperId: selectedPaperId, reviewer, rating, review: text });
      await Promise.all([refreshPapers(), utils.research.detail.invalidate({ paperId: selectedPaperId })]);
      setDialog(null);
      toast.success("Your review is now part of the paper's discussion.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not publish that review.");
    }
  };
  const handleExport = () => {
    if (!detailPaper) return;
    const sourceRows = detailData?.sources?.map((source: any) => ({ contributor: source.contributor, title: source.title, content: source.content ?? "", citationUrl: source.citationUrl ?? undefined })) ?? detailPaper.sources ?? [];
    setExportText(markdownForNotion(detailPaper, sourceRows));
    setDialog("export");
  };
  const copyExport = async () => {
    try {
      await navigator.clipboard.writeText(exportText);
      toast.success("Notion-ready page copied. Paste it into your workspace to publish.");
    } catch {
      toast.error("Clipboard access was blocked. Select the page text and copy it manually.");
    }
  };

  const topPapers = publicPapers.filter(paper => paper.status === "published").slice(0, 3);
  const reviewTotal = publicPapers.reduce((total, paper) => total + paper.reviewCount, 0);
  const teamTotal = new Set(publicPapers.map(paper => paper.team)).size;
  const meanRating = reviewTotal ? (publicPapers.reduce((total, paper) => total + paper.rating * paper.reviewCount, 0) / reviewTotal).toFixed(1) : "—";

  return (
    <WorkspaceShell activeNav={activeNav} setActiveNav={setActiveNav} search={search} setSearch={setSearch} onNewPaper={handleNewPaper} user={user} isTeamMember={isTeamMember} isAdmin={Boolean(isAdmin)} onLogin={handleLogin} onLogout={() => void handleLogout()}>
      {activeNav === "lab" && !isTeamMember ? (
        <div className="dashboard-page"><section className="private-gate"><span className="eyebrow"><span className="welcome-dot" /> SIGN IN TO COLLABORATE</span><h1>Good work is<br /><em>shared work.</em></h1><p>Sign in with any Manus account to open the shared lab, contribute research sources, and edit drafts.</p><button className="button-primary" onClick={handleLogin}>Sign in with Manus <ArrowRight size={15} /></button><button className="gate-return" onClick={() => setActiveNav("discover")}>Return to public papers <ArrowLeft size={14} /></button></section></div>
      ) : selectedPaper && detailPaper ? <DetailView paper={detailPaper} detailData={detailData} onBack={() => setSelectedPaperId(null)} onAddSource={() => setDialog("contribution")} onReview={() => setDialog("review")} onSynthesize={handleSynthesis} onExport={handleExport} onPublish={handlePublish} onPublishNotion={handlePublishToNotion} publishPending={publishPaper.isPending} notionPending={publishNotion.isPending} notionConnected={Boolean(notionStatus.data?.configured)} synthPending={synthesize.isPending} canEdit={isTeamMember && !detailPaper.isDemo} canReview={detailPaper.status === "published" && !detailPaper.isDemo} isAdmin={Boolean(isAdmin)} /> : (
        <div className="dashboard-page">
          <section className="welcome-strip"><div><span className="eyebrow"><span className="welcome-dot" /> THE OPEN RESEARCH WORKSPACE</span><h1>Good research has<br /><em>a paper trail.</em></h1><p>Bring your sources together. Shape a clearer question. Share what holds up.</p><div className="welcome-actions"><button className="button-primary" onClick={handleNewPaper}><Plus size={16} /> {isTeamMember ? "Start a paper" : "Sign in to contribute"}</button><button className="button-quiet" onClick={() => { setActiveNav("discover"); document.querySelector(".library-section")?.scrollIntoView({ behavior: "smooth" }); }}>Explore the library <ArrowDownRight size={15} /></button></div></div><div className="welcome-art" aria-hidden="true"><span className="orbit orbit-one" /><span className="orbit orbit-two" /><span className="orbit orbit-three" /><span className="orbit-label label-a">SOURCE 01</span><span className="orbit-label label-b">DRAFT → v.03</span><span className="orbit-core"><span>n</span><i /></span><span className="orbit-node node-one" /><span className="orbit-node node-two" /><span className="orbit-node node-three" /><span className="orbit-note">ideas, in conversation</span></div><div className="welcome-footnote"><span>01</span> Team-first · source-led · version-aware</div></section>

          <section className="stats-row" aria-label="Sample collection metrics">
            <div className="stat-cell"><span className="stat-icon"><BookOpen size={16} /></span><div><strong>{shortNumber(papers.length)}</strong><small>papers in this sample</small></div><span className="stat-trend">DEMO</span></div>
            <div className="stat-cell"><span className="stat-icon stat-icon-olive"><UsersRound size={16} /></span><div><strong>{teamTotal}</strong><small>teams represented</small></div><span className="stat-trend">DEMO</span></div>
            <div className="stat-cell"><span className="stat-icon stat-icon-rose"><Star size={16} /></span><div><strong>{meanRating} <small>/ 5</small></strong><small>sample average</small></div><span className="stat-trend">{shortNumber(reviewTotal)} ratings</span></div>
            <div className="stat-aside-note"><span className="margin-mark">↳</span><span>Open methods make<br />better conversations.</span></div>
          </section>

          <div className="dashboard-columns">
            <section className="library-section">
              <div className="section-headline"><div><span className="eyebrow">THE COMMONS · {resultPapers.length} PAPERS</span><h2>{activeNav === "lab" ? "Your lab, in progress." : "Papers with momentum."}</h2><p>{activeNav === "lab" ? "Keep your team's sources, drafts, and revisions close." : "Thoughtful research, made easier to find."}</p></div><button className="button-quiet filter-button" onClick={() => setSortBy(sortBy === "momentum" ? "recent" : "momentum")}><SlidersHorizontal size={15} /> {sortBy === "momentum" ? "Most discussed" : "Recently added"}<ChevronDown size={13} /></button></div>
              <div className="category-tabs" role="tablist" aria-label="Filter by research area">{categories.map(item => <button key={item} className={category === item ? "selected" : ""} onClick={() => setCategory(item)}>{item}{category === item && <span className="tab-underline" />}</button>)}<button className="all-filters" onClick={() => setCategory("All papers")}><Filter size={14} /> Filters</button></div>
              {search && <div className="search-result-line"><Search size={14} /> Showing results for <strong>“{search}”</strong><button onClick={() => setSearch("")}>Clear <X size={12} /></button></div>}
              {listQuery.isLoading && <div className="loading-strip"><span className="button-spinner" />Gathering the commons…</div>}
              {resultPapers.length ? <div className="paper-list">{resultPapers.map((paper, index) => <motion.div key={paper.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * .045 }}><PaperCard paper={paper} onOpen={() => setSelectedPaperId(paper.id)} /></motion.div>)}</div> : <div className="empty-state"><Search size={20} /><h3>No papers found.</h3><p>Try another topic or clear your filters.</p><button className="button-quiet" onClick={() => { setSearch(""); setCategory("All papers"); }}>Clear filters</button></div>}
              <button className="load-more" onClick={() => toast("You're looking at the latest papers in this demo collection.")}>You're all caught up <span>·</span> <span>New research is added every day</span></button>
            </section>
            <aside className="dashboard-aside">
              <section className="activity-card"><div className="aside-section-title"><span className="eyebrow">IN THE MARGINS · DEMO</span><button className="icon-button tiny-button" aria-label="More activity"><MoreHorizontal size={18} /></button></div><h3>Research moves<br /><em>in good company.</em></h3><div className="activity-stats"><div><strong>24</strong><span>sample contributions</span></div><div><strong>08</strong><span>sample revisions</span></div></div><div className="activity-divider" /><div className="activity-line"><span className="activity-avatar avatar-olive">I</span><div><p><strong>Inez Parker</strong> added a source to <button onClick={() => setSelectedPaperId("demo-classroom")}>Classroom writing partners</button></p><small>Sample activity · Learning Futures</small></div></div><div className="activity-line"><span className="activity-avatar avatar-blue">T</span><div><p><strong>Tomas Okafor</strong> opened a new review</p><small>Sample activity · Open Methods</small></div></div><button className="aside-text-link" onClick={() => toast("The full community activity feed is coming soon.")}>View community activity <ArrowRight size={14} /></button></section>
              <section className="editor-note"><span className="editor-note-label"><NotebookPen size={13} /> EDITOR'S NOTE</span><p>“A strong synthesis doesn't smooth over disagreement. It gives the next reader a place to start.”</p><div><span className="editor-mark">m.</span><span><strong>Morgan Lee</strong><small>Research editor · Northstar Lab</small></span></div></section>
              <section className="trending-card"><div className="trending-head"><span className="eyebrow">MOST RETURNED TO</span><TrendingIcon /></div>{topPapers.slice(0, 3).map((paper, index) => <button className="trending-row" key={paper.id} onClick={() => setSelectedPaperId(paper.id)}><span className="trending-number">0{index + 1}</span><span><strong>{paper.title}</strong><small>{paper.category} · {paper.reviewCount} conversations</small></span><ArrowUpRight size={14} /></button>)}</section>
              <div className="dashboard-note"><span>◌</span><p>All sample papers are fictional. Build your own source trail to start a real research conversation.</p></div>
            </aside>
          </div>
          <footer className="dashboard-footer"><span>NUYTELAB <i>·</i> A calmer way to work in the open.</span><span><button onClick={() => toast("Community guidelines are being drafted for the hackathon launch.")}>Community guidelines</button><span>·</span><button onClick={() => toast("Nuytelab is a research collaboration prototype.")}>About the project</button></span></footer>
        </div>
      )}
      {dialog === "create" && isTeamMember && user && <CreatePaperDialog memberName={user.name || user.email || "Manus member"} onClose={() => setDialog(null)} onCreate={handleCreate} pending={createPaper.isPending || synthesize.isPending} />}
      {dialog === "contribution" && selectedPaper && isTeamMember && user && <ContributionDialog paperTitle={selectedPaper.title} memberName={user.name || user.email || "Manus member"} onClose={() => setDialog(null)} onSubmit={handleContribution} pending={addContribution.isPending} />}
      {dialog === "review" && selectedPaper && selectedPaper.status === "published" && !selectedPaper.isDemo && <ReviewDialog paper={selectedPaper} onClose={() => setDialog(null)} onSubmit={handleReview} pending={submitReview.isPending} />}
      {dialog === "export" && <div className="dialog-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) setDialog(null); }}><motion.div className="dialog-card export-dialog" role="dialog" aria-modal="true" aria-labelledby="export-title" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}><div className="dialog-header"><div><span className="eyebrow">NOTION-READY EXPORT</span><h2 id="export-title">A page worth sharing.</h2><p>Copy this structured draft into your Notion workspace. Review its sources before publishing.</p></div><button className="icon-button" onClick={() => setDialog(null)} aria-label="Close"><X size={18} /></button></div><textarea className="export-textarea" value={exportText} onChange={event => setExportText(event.target.value)} rows={14} /><div className="export-note"><span className="notion-stamp notion-stamp-small">N</span><span>Export prepared locally · Not synced to Notion</span></div><div className="dialog-footer"><button className="button-quiet" onClick={() => setDialog(null)}>Close</button><button className="button-primary" onClick={() => void copyExport()}><Copy size={15} /> Copy page</button></div></motion.div></div>}
    </WorkspaceShell>
  );
}

function TrendingIcon() {
  return <span className="trending-icon"><ArrowUpRight size={15} /></span>;
}
