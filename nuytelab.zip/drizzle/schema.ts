import {
  double,
  int,
  longtext,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing the starter's Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Email allowlist managed by the project owner; a matching Manus account is required. */
export const researchTeamMembers = mysqlTable("research_team_members", {
  id: varchar("id", { length: 36 }).primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  invitedByOpenId: varchar("invitedByOpenId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [uniqueIndex("uq_research_team_email").on(table.email)]);

export const researchPapers = mysqlTable("research_papers", {
  id: varchar("id", { length: 36 }).primaryKey(),
  slug: varchar("slug", { length: 190 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  abstract: text("abstract").notNull(),
  summary: longtext("summary").notNull(),
  /** Private legacy excerpt. Public projections never return this field. */
  paperBody: longtext("paperBody").notNull(),
  author: varchar("author", { length: 140 }).notNull(),
  createdByOpenId: varchar("createdByOpenId", { length: 64 }),
  team: varchar("team", { length: 140 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  tags: text("tags").notNull(),
  averageRating: double("averageRating").default(0).notNull(),
  reviewCount: int("reviewCount").default(0).notNull(),
  readCount: int("readCount").default(0).notNull(),
  sourceCount: int("sourceCount").default(0).notNull(),
  version: int("version").default(1).notNull(),
  status: mysqlEnum("status", ["draft", "in_review", "published"]).default("draft").notNull(),
  isDemo: int("isDemo").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const paperContributions = mysqlTable("paper_contributions", {
  id: varchar("id", { length: 36 }).primaryKey(),
  paperId: varchar("paperId", { length: 36 }).notNull().references(() => researchPapers.id, { onDelete: "cascade" }),
  contributor: varchar("contributor", { length: 140 }).notNull(),
  contributorOpenId: varchar("contributorOpenId", { length: 64 }),
  title: varchar("title", { length: 255 }).notNull(),
  content: longtext("content").notNull(),
  citationUrl: varchar("citationUrl", { length: 1000 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const paperRevisions = mysqlTable("paper_revisions", {
  id: varchar("id", { length: 36 }).primaryKey(),
  paperId: varchar("paperId", { length: 36 }).notNull().references(() => researchPapers.id, { onDelete: "cascade" }),
  version: int("version").notNull(),
  summary: longtext("summary").notNull(),
  changeNote: varchar("changeNote", { length: 255 }).notNull(),
  createdBy: varchar("createdBy", { length: 140 }).notNull(),
  createdByOpenId: varchar("createdByOpenId", { length: 64 }),
  /** Only explicitly approved commons releases are visible in public version history. */
  isPublished: int("isPublished").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [uniqueIndex("uq_paper_revision_version").on(table.paperId, table.version)]);

export const paperReviews = mysqlTable("paper_reviews", {
  id: varchar("id", { length: 36 }).primaryKey(),
  paperId: varchar("paperId", { length: 36 }).notNull().references(() => researchPapers.id, { onDelete: "cascade" }),
  reviewer: varchar("reviewer", { length: 140 }).notNull(),
  rating: int("rating").notNull(),
  review: text("review").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [uniqueIndex("uq_paper_review_name").on(table.paperId, table.reviewer)]);

export const paperNotionPublications = mysqlTable("paper_notion_publications", {
  id: varchar("id", { length: 36 }).primaryKey(),
  paperId: varchar("paperId", { length: 36 }).notNull().references(() => researchPapers.id, { onDelete: "cascade" }),
  version: int("version").notNull(),
  notionPageId: varchar("notionPageId", { length: 64 }).notNull(),
  notionUrl: varchar("notionUrl", { length: 1000 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [uniqueIndex("uq_notion_paper_version").on(table.paperId, table.version)]);
