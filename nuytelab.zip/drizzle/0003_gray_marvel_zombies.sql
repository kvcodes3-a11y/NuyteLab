CREATE TABLE `research_team_members` (
	`id` varchar(36) NOT NULL,
	`email` varchar(320) NOT NULL,
	`invitedByOpenId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `research_team_members_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_research_team_email` UNIQUE(`email`)
);
--> statement-breakpoint
ALTER TABLE `paper_contributions` ADD `contributorOpenId` varchar(64);--> statement-breakpoint
ALTER TABLE `paper_revisions` ADD `createdByOpenId` varchar(64);--> statement-breakpoint
ALTER TABLE `paper_revisions` ADD `isPublished` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `research_papers` ADD `createdByOpenId` varchar(64);--> statement-breakpoint
ALTER TABLE `paper_notion_publications` ADD CONSTRAINT `uq_notion_paper_version` UNIQUE(`paperId`,`version`);--> statement-breakpoint
ALTER TABLE `paper_reviews` ADD CONSTRAINT `uq_paper_review_name` UNIQUE(`paperId`,`reviewer`);--> statement-breakpoint
ALTER TABLE `paper_revisions` ADD CONSTRAINT `uq_paper_revision_version` UNIQUE(`paperId`,`version`);