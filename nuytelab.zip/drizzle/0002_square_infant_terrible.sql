CREATE TABLE `paper_notion_publications` (
	`id` varchar(36) NOT NULL,
	`paperId` varchar(36) NOT NULL,
	`version` int NOT NULL,
	`notionPageId` varchar(64) NOT NULL,
	`notionUrl` varchar(1000) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_notion_publications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `paper_notion_publications` ADD CONSTRAINT `paper_notion_publications_paperId_research_papers_id_fk` FOREIGN KEY (`paperId`) REFERENCES `research_papers`(`id`) ON DELETE cascade ON UPDATE no action;