CREATE TABLE `paper_contributions` (
	`id` varchar(36) NOT NULL,
	`paperId` varchar(36) NOT NULL,
	`contributor` varchar(140) NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` longtext NOT NULL,
	`citationUrl` varchar(1000),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_contributions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_reviews` (
	`id` varchar(36) NOT NULL,
	`paperId` varchar(36) NOT NULL,
	`reviewer` varchar(140) NOT NULL,
	`rating` int NOT NULL,
	`review` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_revisions` (
	`id` varchar(36) NOT NULL,
	`paperId` varchar(36) NOT NULL,
	`version` int NOT NULL,
	`summary` longtext NOT NULL,
	`changeNote` varchar(255) NOT NULL,
	`createdBy` varchar(140) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_revisions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `research_papers` (
	`id` varchar(36) NOT NULL,
	`slug` varchar(190) NOT NULL,
	`title` varchar(255) NOT NULL,
	`abstract` text NOT NULL,
	`summary` longtext NOT NULL,
	`paperBody` longtext NOT NULL,
	`author` varchar(140) NOT NULL,
	`team` varchar(140) NOT NULL,
	`category` varchar(80) NOT NULL,
	`tags` text NOT NULL,
	`averageRating` double NOT NULL DEFAULT 0,
	`reviewCount` int NOT NULL DEFAULT 0,
	`readCount` int NOT NULL DEFAULT 0,
	`sourceCount` int NOT NULL DEFAULT 0,
	`version` int NOT NULL DEFAULT 1,
	`status` enum('draft','in_review','published') NOT NULL DEFAULT 'draft',
	`isDemo` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `research_papers_id` PRIMARY KEY(`id`),
	CONSTRAINT `research_papers_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `paper_contributions` ADD CONSTRAINT `paper_contributions_paperId_research_papers_id_fk` FOREIGN KEY (`paperId`) REFERENCES `research_papers`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `paper_reviews` ADD CONSTRAINT `paper_reviews_paperId_research_papers_id_fk` FOREIGN KEY (`paperId`) REFERENCES `research_papers`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `paper_revisions` ADD CONSTRAINT `paper_revisions_paperId_research_papers_id_fk` FOREIGN KEY (`paperId`) REFERENCES `research_papers`(`id`) ON DELETE cascade ON UPDATE no action;