export type DemoSource = {
  contributor: string;
  title: string;
  content: string;
  citationUrl?: string;
};

export type DemoPaper = {
  id: string;
  slug: string;
  title: string;
  abstract: string;
  summary: string;
  paperBody: string;
  author: string;
  team: string;
  category: string;
  tags: string[];
  rating: number;
  reviewCount: number;
  readTime: number;
  version: number;
  status: "published" | "in_review" | "draft";
  createdAt: string;
  isDemo: true;
  sources: DemoSource[];
};

// Fictional, clearly labeled demo content for the hackathon prototype.
export const demoPapers: DemoPaper[] = [
  {
    id: "demo-retrieval",
    slug: "retrieval-notes",
    title: "How researchers actually use retrieval-augmented generation",
    abstract: "A field note on what changes when teams treat retrieval as a research practice, not a model feature.",
    summary: "## Abstract\nRetrieval-augmented systems are most useful when researchers can inspect which evidence shaped an answer. This fictional demo synthesis suggests that source visibility, correction loops, and narrow questions matter at least as much as larger context windows.\n\n## Key findings\n- A visible source trail makes it easier to notice when evidence is stale or off-topic.\n- Teams benefit from saving question phrasing alongside the supporting sources.\n- Retrieval should be evaluated on whether it helps people verify claims, not only on whether it returns a plausible passage.\n\n## Limitations\nThis is sample content created for the Nuytelab prototype and is not a real empirical study.",
    paperBody: "## Abstract\nThis demo paper sketches how a small research group might organize observations about retrieval-augmented generation (RAG). The emphasis is on evidence lineage rather than system performance.\n\n## Working question\nWhen does a retrieval interface help a reader verify a claim instead of simply making an answer sound more confident?\n\n## Notes from the source bundle\nThe sample bundle points to three recurring design questions: whether a citation opens at the relevant passage, whether users can flag a mismatch, and whether a team can preserve the question that produced a useful retrieval result.\n\n## Synthesis\nThe group’s working hypothesis is that inspectability is a product property. A system that exposes its sources can invite users to challenge, compare, and repair evidence. A system that only displays a fluent answer asks readers to trust a hidden selection process.\n\n## Limitations\nThese notes are invented demo material, not a research result. Replace them with cited source documents before publishing a real paper.",
    author: "Mira Chen",
    team: "Northstar Lab",
    category: "AI & Society",
    tags: ["RAG", "Research methods", "Human-AI"],
    rating: 4.8,
    reviewCount: 26,
    readTime: 7,
    version: 3,
    status: "published",
    createdAt: "2026-09-28T10:20:00.000Z",
    isDemo: true,
    sources: [
      { contributor: "Mira Chen", title: "Source bundle A · Evidence lineage", content: "Fictional demo note: readers report greater confidence when citations point to the exact passage that supports a claim. They want a way to flag outdated or irrelevant retrieval results." },
      { contributor: "Evan Li", title: "Source bundle B · Evaluation questions", content: "Fictional demo note: retrieval should be checked for coverage, relevance, and the reader's ability to verify claims. A plausible answer is not by itself a measure of evidence quality." },
      { contributor: "Sam Rivera", title: "Source bundle C · Team workflow", content: "Fictional demo note: preserving the original question and the selected sources helps a team compare useful retrieval paths and revisit them later." },
    ],
  },
  {
    id: "demo-classroom",
    slug: "classroom-writing-partners",
    title: "Small language models as classroom writing partners",
    abstract: "A practical framework for keeping student agency visible when AI tools enter the writing process.",
    summary: "## Working synthesis\nThis fictional example proposes that classroom AI should leave room for student authorship. Helpful patterns include opt-in feedback, visible revision history, and prompts that invite reflection instead of replacing the student's next move.\n\n## Questions to test\n- Can a learner explain why they accepted or rejected a suggestion?\n- Does the interface preserve a clear boundary between generated and student-authored text?\n\n## Limitations\nDemonstration copy only; no real classroom study is represented.",
    paperBody: "## Abstract\nA fictional research note about maintaining student agency in AI-assisted writing.\n\n## Working synthesis\nDesign should prioritize learner control, transparent suggestions, and the ability to compare revisions. The interface can ask a question, point to a pattern, or offer a counterexample without silently rewriting the work.\n\n## Limitations\nDemonstration copy only; no real classroom study is represented.",
    author: "Inez Parker",
    team: "Learning Futures Group",
    category: "Education",
    tags: ["Learning", "Writing", "AI ethics"],
    rating: 4.7,
    reviewCount: 18,
    readTime: 5,
    version: 2,
    status: "published",
    createdAt: "2026-09-24T13:15:00.000Z",
    isDemo: true,
    sources: [
      { contributor: "Inez Parker", title: "Source bundle A · Learner agency", content: "Fictional demo note: keep students in control of suggestions and make it easy to compare alternatives." },
      { contributor: "Jun Seo", title: "Source bundle B · Revision traces", content: "Fictional demo note: a visible revision trail may help learners discuss how their thinking changed." },
    ],
  },
  {
    id: "demo-evaluation",
    slug: "agent-evaluation-notes",
    title: "Toward more reproducible evaluation of AI agents",
    abstract: "A working note on reporting task context, tool access, and failure conditions alongside benchmark scores.",
    summary: "## Summary\nThis fictional demo argues that a benchmark result is easier to interpret when teams record the task setup, available tools, stopping rules, and failure cases.\n\n## Useful reporting details\n- State which tools and permissions were available.\n- Keep examples of incomplete or failed runs, not only successful traces.\n- Separate reproducibility evidence from performance claims.\n\n## Status\nA discussion draft seeking methodological review.",
    paperBody: "## Abstract\nA fictional methods note on making AI-agent evaluation easier to reproduce.\n\n## Reporting checklist\nDescribe the task, model, tool permissions, starting state, stopping rule, and evaluation rubric. Preserve failures and explain how multiple attempts were handled.\n\n## Limitations\nThis is synthetic example content for a product demo, not a benchmark study.",
    author: "Tomas Okafor",
    team: "Open Methods Collective",
    category: "Computer Science",
    tags: ["Evaluation", "Agents", "Reproducibility"],
    rating: 4.9,
    reviewCount: 41,
    readTime: 9,
    version: 5,
    status: "in_review",
    createdAt: "2026-09-22T08:40:00.000Z",
    isDemo: true,
    sources: [
      { contributor: "Tomas Okafor", title: "Source bundle A · Setup records", content: "Fictional demo note: results are hard to compare when tool access, task context, or stop conditions are omitted." },
      { contributor: "Nadia Bell", title: "Source bundle B · Failure cases", content: "Fictional demo note: preserving incomplete trajectories can reveal where an agent's procedure is fragile." },
    ],
  },
  {
    id: "demo-community",
    slug: "community-science-notes",
    title: "Open data, local questions: a field guide to community science",
    abstract: "A field guide concept for connecting locally meaningful questions with reusable, well-described datasets.",
    summary: "## Field guide\nThis fictional example frames community science as a cycle: define a local question, document how observations were gathered, and publish data with enough context for careful reuse.\n\n## Editorial note\nA dataset is not self-explanatory. Collection conditions, gaps, and community priorities belong beside the numbers.\n\n## Limitations\nDemo material only. No real community or dataset is described.",
    paperBody: "## Abstract\nA fictional field note on documenting local knowledge and reusable data.\n\n## Working principles\nDocument collection conditions, represent missingness honestly, and invite participants to review how results are summarized.\n\n## Limitations\nDemo material only. No real community or dataset is described.",
    author: "Avery James",
    team: "Common Ground Research",
    category: "Climate & Place",
    tags: ["Open data", "Community", "Field methods"],
    rating: 4.6,
    reviewCount: 12,
    readTime: 6,
    version: 1,
    status: "published",
    createdAt: "2026-09-20T16:05:00.000Z",
    isDemo: true,
    sources: [
      { contributor: "Avery James", title: "Source bundle A · Collection context", content: "Fictional demo note: context about collection methods and local priorities should travel with the dataset." },
      { contributor: "Rae Thompson", title: "Source bundle B · Responsible reuse", content: "Fictional demo note: teams should describe gaps and ask community contributors to review public summaries." },
    ],
  },
];
