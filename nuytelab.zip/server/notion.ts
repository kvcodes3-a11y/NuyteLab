import { TRPCError } from "@trpc/server";

export type NotionSource = {
  title: string;
  contributor: string;
  citationUrl?: string | null;
};

export type NotionPaper = {
  title: string;
  date: string;
  review: string;
  abstract: string;
  summary: string;
  version: number;
  team: string;
  author: string;
  category: string;
  sources: NotionSource[];
};

const NOTION_VERSION = "2026-03-11";
const MAX_BLOCKS = 95;
const TEXT_CHUNK = 1800;
const NOTION_API = "https://api.notion.com/v1";

type NotionResponse = {
  response: Response;
  body: Record<string, any>;
};

type ResolvedParent = {
  parent: { type: "data_source_id"; data_source_id: string };
  nameProperty: string;
  dateProperty: string;
  summaryProperty: string;
  reviewProperty: string;
};

function normalizedNotionId(value: string) {
  let source = value.trim();
  try {
    if (/^https?:\/\//i.test(source)) {
      const url = new URL(source);
      source = decodeURIComponent(`${url.pathname} ${url.search} ${url.hash}`);
    }
  } catch {
    // Keep the original value for the ID parser below.
  }
  const match = source.match(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}|[a-f0-9]{32}/i);
  if (!match) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "The Notion target ID or URL is invalid. Enter a database URL shared with the integration." });
  const compact = match[0].replace(/-/g, "").toLowerCase();
  return `${compact.slice(0, 8)}-${compact.slice(8, 12)}-${compact.slice(12, 16)}-${compact.slice(16, 20)}-${compact.slice(20)}`;
}

export function notionConfigured() {
  return Boolean(process.env.NUYTELAB_NOTION_TOKEN && process.env.NUYTELAB_NOTION_PARENT_PAGE_ID);
}

async function notionRequest(path: string, token: string, method = "GET", body?: unknown): Promise<NotionResponse> {
  let response: Response;
  try {
    response = await fetch(`${NOTION_API}${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "Notion-Version": NOTION_VERSION,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.timeout(method === "POST" ? 20000 : 12000),
    });
  } catch {
    throw new TRPCError({ code: "BAD_GATEWAY", message: "Nuytelab could not reach Notion. Try again after checking the connection." });
  }
  const parsed = await response.json().catch(() => ({}));
  return { response, body: parsed && typeof parsed === "object" ? parsed as Record<string, any> : {} };
}

async function resolveParent(token: string, rawTarget: string): Promise<ResolvedParent> {
  const targetId = normalizedNotionId(rawTarget);
  const database = await notionRequest(`/databases/${targetId}`, token);
  if (!database.response.ok) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Direct Notion publishing needs a database target with Name, Date, Summary, and Review columns. Use the connected database URL or ID." });
  }
  const sources = Array.isArray(database.body.data_sources) ? database.body.data_sources : [];
  if (sources.length !== 1 || typeof sources[0]?.id !== "string") {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: "The connected Notion database must have exactly one data source." });
  }
  const dataSourceId = normalizedNotionId(sources[0].id);
  const schema = await notionRequest(`/data_sources/${dataSourceId}`, token);
  if (!schema.response.ok) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Notion could not read the connected database schema. Share the database with the integration and allow it to read content." });
  }
  const properties = schema.body.properties && typeof schema.body.properties === "object" ? schema.body.properties as Record<string, { type?: string }> : {};
  const titleProperties = Object.entries(properties).filter(([, property]) => property?.type === "title").map(([name]) => name);
  if (titleProperties.length !== 1 || titleProperties[0] !== "Name" || properties.Date?.type !== "date" || properties.Summary?.type !== "rich_text" || properties.Review?.type !== "rich_text") {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: "The Notion data source must have these columns: Name (title), Date (date), Summary (rich text), and Review (rich text)." });
  }
  return {
    parent: { type: "data_source_id", data_source_id: dataSourceId },
    nameProperty: "Name",
    dateProperty: "Date",
    summaryProperty: "Summary",
    reviewProperty: "Review",
  };
}

function richText(content: string) {
  const characters = [...content];
  const chunks: string[] = [];
  for (let offset = 0; offset < characters.length; offset += TEXT_CHUNK) {
    chunks.push(characters.slice(offset, offset + TEXT_CHUNK).join(""));
  }
  if (chunks.length > 100) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "The summary is too long for a Notion text cell. Shorten the synthesis before publishing." });
  }
  return (chunks.length ? chunks : [" "]).map(text => ({ type: "text", text: { content: text } }));
}

function textBlock(type: string, text: string) {
  if (!text.trim()) return null;
  return { object: "block", type, [type]: { rich_text: richText(text) } };
}

function cleanMarkdown(text: string) {
  return text.replace(/\*\*(.*?)\*\*/g, "$1").replace(/__(.*?)__/g, "$1").replace(/\*([^*]+)\*/g, "$1").replace(/`([^`]+)`/g, "$1").trim();
}

function reviewCellText(text: string) {
  const plain = cleanMarkdown(text)
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^\s*[-*]\s+/gm, "")
    .replace(/\s+/g, " ")
    .trim();
  const limit = 600;
  return plain.length > limit ? `${plain.slice(0, limit - 1).trimEnd()}…` : plain || "No synthesis available.";
}

function summaryCellText(text: string) {
  return text
    .replace(/\r/g, "")
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^\s*[-*]\s+/gm, "• ")
    .replace(/^\s*\d+[.)]\s+/gm, "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/__(.*?)__/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function markdownBlocks(markdown: string) {
  const blocks: Array<Record<string, unknown>> = [];
  let paragraph: string[] = [];
  const flushParagraph = () => {
    if (!paragraph.length) return;
    const joined = cleanMarkdown(paragraph.join(" "));
    for (let offset = 0; offset < joined.length; offset += TEXT_CHUNK) {
      const block = textBlock("paragraph", joined.slice(offset, offset + TEXT_CHUNK));
      if (block) blocks.push(block as Record<string, unknown>);
    }
    paragraph = [];
  };
  const lines = markdown.replace(/\r/g, "").split("\n");
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) { flushParagraph(); continue; }
    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) {
      flushParagraph();
      const type = heading[1].length === 1 ? "heading_2" : "heading_3";
      const block = textBlock(type, cleanMarkdown(heading[2]));
      if (block) blocks.push(block as Record<string, unknown>);
    } else if (line.startsWith("> ")) {
      flushParagraph();
      const block = textBlock("quote", cleanMarkdown(line.slice(2)));
      if (block) blocks.push(block as Record<string, unknown>);
    } else if (/^[-*]\s+/.test(line)) {
      flushParagraph();
      const block = textBlock("bulleted_list_item", cleanMarkdown(line.replace(/^[-*]\s+/, "")));
      if (block) blocks.push(block as Record<string, unknown>);
    } else if (/^\d+[.)]\s+/.test(line)) {
      flushParagraph();
      const block = textBlock("numbered_list_item", cleanMarkdown(line.replace(/^\d+[.)]\s+/, "")));
      if (block) blocks.push(block as Record<string, unknown>);
    } else {
      paragraph.push(line);
    }
    if (blocks.length >= MAX_BLOCKS - 4) break;
  }
  flushParagraph();
  return blocks.slice(0, MAX_BLOCKS - 4);
}

export async function createNotionPaperPage(paper: NotionPaper) {
  const token = process.env.NUYTELAB_NOTION_TOKEN?.trim();
  const rawTarget = process.env.NUYTELAB_NOTION_PARENT_PAGE_ID?.trim();
  if (!token || !rawTarget) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Connect a Notion integration token and database URL before publishing." });
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(paper.date)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "The Nuytelab release date must use YYYY-MM-DD format." });
  }

  const resolved = await resolveParent(token, rawTarget);
  const blocks: Array<Record<string, unknown>> = [];
  blocks.push(textBlock("heading_2", "Abstract") as Record<string, unknown>);
  blocks.push(textBlock("paragraph", paper.abstract) as Record<string, unknown>);
  blocks.push(textBlock("paragraph", `${paper.team} · ${paper.category} · Version ${paper.version} · Led by ${paper.author}`) as Record<string, unknown>);
  blocks.push(...markdownBlocks(paper.summary));
  blocks.push(textBlock("heading_2", "Contributing sources") as Record<string, unknown>);
  for (let index = 0; index < paper.sources.length && blocks.length < MAX_BLOCKS - 2; index += 1) {
    const source = paper.sources[index];
    const title = `[S${index + 1}] ${source.title} — ${source.contributor}`;
    if (source.citationUrl) {
      blocks.push({
        object: "block",
        type: "paragraph",
        paragraph: { rich_text: [
          { type: "text", text: { content: title } },
          { type: "text", text: { content: " · Open source", link: { url: source.citationUrl } } },
        ] },
      });
    } else {
      blocks.push(textBlock("paragraph", title) as Record<string, unknown>);
    }
  }
  blocks.push(textBlock("paragraph", "Prepared with Nuytelab · Review the original source material before relying on this synthesis.") as Record<string, unknown>);
  const title = paper.title.slice(0, 2000);
  const titleValue = { title: [{ type: "text", text: { content: title } }] };
  const properties = {
    [resolved.nameProperty]: titleValue,
    [resolved.dateProperty]: { date: { start: paper.date } },
    [resolved.summaryProperty]: { rich_text: richText(summaryCellText(paper.summary)) },
    [resolved.reviewProperty]: { rich_text: richText(reviewCellText(paper.review)) },
  };

  const created = await notionRequest("/pages", token, "POST", {
    parent: resolved.parent,
    properties,
    children: blocks.slice(0, 100),
  });
  const result = created.body as { id?: string; url?: string };
  if (!created.response.ok || !result.id || !result.url) {
    if (created.response.status === 401) throw new TRPCError({ code: "UNAUTHORIZED", message: "Notion rejected the integration token. Update the protected connection setting." });
    if (created.response.status === 403 || created.response.status === 404) throw new TRPCError({ code: "FORBIDDEN", message: "Notion could not access the target. Use Add connections to share the page or database with the integration." });
    if (created.response.status === 400) throw new TRPCError({ code: "BAD_REQUEST", message: "Notion rejected the database row. Check the Name, Date, Summary, and Review property types and integration permissions." });
    throw new TRPCError({ code: "BAD_GATEWAY", message: "Notion could not create this page. Check the target permissions and try again." });
  }
  return { pageId: result.id, url: result.url };
}
