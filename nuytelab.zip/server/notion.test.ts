import { afterEach, describe, expect, it, vi } from "vitest";
import { createNotionPaperPage } from "./notion";

afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); });

const databaseId = "11111111111141118111111111111111";
const dataSourceId = "22222222222242228222222222222222";
const success = (body: unknown) => new Response(JSON.stringify(body), {
  status: 200,
  headers: { "content-type": "application/json" },
});
const paper = {
  title: "A Source-Grounded Research Paper",
  date: "2026-10-03",
  review: "# Main finding\nA concise synthesis of the submitted evidence.",
  abstract: "A short abstract for the public paper.",
  summary: "# Main finding\nA concise synthesis of the submitted evidence.",
  version: 3,
  team: "Nuytelab research team",
  author: "Research lead",
  category: "AI & Society",
  sources: [{ title: "Source draft", contributor: "Team member", citationUrl: "https://example.org/paper" }],
};
const properties = {
  Name: { type: "title" },
  Date: { type: "date" },
  Summary: { type: "rich_text" },
  Review: { type: "rich_text" },
};

function stubConnection() {
  vi.stubEnv("NUYTELAB_NOTION_TOKEN", "test-token-only");
  vi.stubEnv("NUYTELAB_NOTION_PARENT_PAGE_ID", databaseId);
}

function stubSuccessfulPublish() {
  const request = vi.fn()
    .mockResolvedValueOnce(success({ data_sources: [{ id: dataSourceId }] }))
    .mockResolvedValueOnce(success({ properties }))
    .mockResolvedValueOnce(success({ id: "33333333333343338333333333333333", url: "https://www.notion.so/example" }));
  vi.stubGlobal("fetch", request);
  return request;
}

describe("Notion table publishing", () => {
  it("writes Name, Date, full Summary, and concise Review properties", async () => {
    stubConnection();
    const request = stubSuccessfulPublish();

    const result = await createNotionPaperPage(paper);
    const createPayload = JSON.parse(request.mock.calls[2][1].body as string);
    const row = createPayload.properties;

    expect(result).toMatchObject({ url: "https://www.notion.so/example" });
    expect(createPayload.parent).toMatchObject({ type: "data_source_id" });
    expect(row.Name.title[0].text.content).toBe(paper.title);
    expect(row.Date.date.start).toBe("2026-10-03");
    expect(row.Summary.rich_text.map((part: { text: { content: string } }) => part.text.content).join(""))
      .toBe("Main finding\nA concise synthesis of the submitted evidence.");
    expect(row.Review.rich_text.map((part: { text: { content: string } }) => part.text.content).join(""))
      .toBe("Main finding A concise synthesis of the submitted evidence.");
    expect(createPayload.children.some((block: { type: string }) => block.type === "heading_2")).toBe(true);
  });

  it("chunks a long Summary cell into Notion-safe rich-text items without losing text", async () => {
    stubConnection();
    const request = stubSuccessfulPublish();
    const longSummary = `# Full synthesis\n${"evidence ".repeat(500)}`;

    await createNotionPaperPage({ ...paper, summary: longSummary });
    const createPayload = JSON.parse(request.mock.calls[2][1].body as string);
    const written = createPayload.properties.Summary.rich_text
      .map((part: { text: { content: string } }) => part.text.content).join("");

    expect(createPayload.properties.Summary.rich_text.length).toBeGreaterThan(1);
    expect(written).toBe(`Full synthesis\n${"evidence ".repeat(500)}`.trimEnd());
  });

  it("refuses a database without the required Summary rich-text property", async () => {
    stubConnection();
    const request = vi.fn()
      .mockResolvedValueOnce(success({ data_sources: [{ id: dataSourceId }] }))
      .mockResolvedValueOnce(success({ properties: { ...properties, Summary: { type: "date" } } }));
    vi.stubGlobal("fetch", request);

    await expect(createNotionPaperPage(paper)).rejects.toMatchObject({ code: "PRECONDITION_FAILED" });
    expect(request).toHaveBeenCalledTimes(2);
  });
});
